public class primePremium {
    public static void main(String [] args){
        int count = 0;
        for(int i =10; count < 3 &&i <=  50;i++){
            if(isPrime(i)){
                System.out.println("Prime number " + i);
                count ++;
            }
        }
    }
    public static boolean isPrime(int number){
        if(number % 2 == 0){
            return false;
        }for (int divisor = 2; divisor <= number/2 ; divisor++) {
            if (number % divisor == 0) {
                return false;
            }
        }
        return true;
    }
}
